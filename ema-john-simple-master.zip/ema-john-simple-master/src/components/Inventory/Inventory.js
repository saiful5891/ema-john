import React from 'react';

const Inventory = () => {
    const handleAddInventory = () =>{
        
    }
    return (
        <div>
            <h1>Add Inventory to Sell more...</h1>
            <button onClick={handleAddInventory} >Add Inventor</button>
        </div>
    );
};

export default Inventory;